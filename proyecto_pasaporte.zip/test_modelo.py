import unittest
from classes.persona import Persona
from classes.pasaporte import Pasaporte
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()
client = MongoClient(os.getenv("MONGO_URI"))
db = client["proyecto_pasaporte"]

class TestModelo(unittest.TestCase):
    def test_creacion_y_relacion(self):
        persona = Persona("Ana Torres", "1995-11-10", "Hondureña")
        persona_id = persona.save()

        pasaporte = Pasaporte("HN87654321", "2022-05-01", "2032-05-01", persona_id)
        pasaporte_id = pasaporte.save()

        persona.update_pasaporte_id(pasaporte_id)

        doc_persona = db["personas"].find_one({"_id": persona_id})
        doc_pasaporte = db["pasaportes"].find_one({"_id": pasaporte_id})

        self.assertIsNotNone(doc_persona)
        self.assertIsNotNone(doc_pasaporte)
        self.assertEqual(doc_pasaporte["persona_id"], persona_id)
        self.assertEqual(doc_persona["pasaporte_id"], pasaporte_id)

if __name__ == "__main__":
    unittest.main()
