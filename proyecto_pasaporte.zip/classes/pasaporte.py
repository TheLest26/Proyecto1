from pymongo import MongoClient
from bson.objectid import ObjectId
import os
from dotenv import load_dotenv

load_dotenv()
client = MongoClient(os.getenv("MONGO_URI"))
db = client["proyecto_pasaporte"]
pasaportes = db["pasaportes"]

class Pasaporte:
    def __init__(self, numero_pasaporte, fecha_emision, fecha_expiracion, persona_id=None):
        self.numero_pasaporte = numero_pasaporte
        self.fecha_emision = fecha_emision
        self.fecha_expiracion = fecha_expiracion
        self.persona_id = persona_id

    def save(self):
        data = {
            "numero_pasaporte": self.numero_pasaporte,
            "fecha_emision": self.fecha_emision,
            "fecha_expiracion": self.fecha_expiracion,
            "persona_id": ObjectId(self.persona_id)
        }
        result = pasaportes.insert_one(data)
        return result.inserted_id
