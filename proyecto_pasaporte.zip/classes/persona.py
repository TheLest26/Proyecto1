from pymongo import MongoClient
from bson.objectid import ObjectId
import os
from dotenv import load_dotenv

load_dotenv()
client = MongoClient(os.getenv("MONGO_URI"))
db = client["proyecto_pasaporte"]
personas = db["personas"]

class Persona:
    def __init__(self, nombre, fecha_nacimiento, nacionalidad):
        self.nombre = nombre
        self.fecha_nacimiento = fecha_nacimiento
        self.nacionalidad = nacionalidad
        self.pasaporte_id = None

    def save(self):
        data = {
            "nombre": self.nombre,
            "fecha_nacimiento": self.fecha_nacimiento,
            "nacionalidad": self.nacionalidad,
            "pasaporte_id": self.pasaporte_id
        }
        result = personas.insert_one(data)
        return result.inserted_id

    def update_pasaporte_id(self, pasaporte_id):
        personas.update_one(
            {"nombre": self.nombre},
            {"$set": {"pasaporte_id": ObjectId(pasaporte_id)}}
        )
