from classes.persona import Persona
from classes.pasaporte import Pasaporte

# Crear persona
persona = Persona("Luis Romero", "1998-05-12", "Hondureña")
persona_id = persona.save()

# Crear pasaporte y asignar persona
pasaporte = Pasaporte("HN12345678", "2023-01-01", "2033-01-01", persona_id)
pasaporte_id = pasaporte.save()

# Actualizar persona con pasaporte_id
persona.update_pasaporte_id(pasaporte_id)

print("Relación 1:1 completada con éxito.")
